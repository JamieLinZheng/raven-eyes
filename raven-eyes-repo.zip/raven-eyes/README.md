# Amber Alert Lens

**Community safety awareness for Raven Prism smart glasses, built for San Francisco.**

Phone alerts get swiped away in seconds. Amber Alert Lens keeps the real, active missing-person and wanted alerts for your area in your periphery. When you see someone or something that might match, look at it and blink **Scan**, or turn on **Auto** for hands-free scanning. The glasses compare what you see with each alert's description. If something lines up, you get a calm card that shows your view next to the official photo, what matched, a confidence level and exactly what to do. **You always make the final call.**

<p>
  <img src="docs/home.png" width="49%" alt="Home: live alerts near you">
  <img src="docs/match.png" width="49%" alt="Possible match card">
</p>
<p>
  <img src="docs/detail.png" width="49%" alt="Alert detail">
  <img src="docs/report.png" width="49%" alt="Sighting logged + who to call">
</p>

## Features

- **Real San Francisco data** pulled on launch, refreshed every 10 minutes and cached for offline use:
  - long-term **missing persons**, crimes against children and wanted fugitives from the FBI's San Francisco field office, with official photos, descriptions and official reward info
  - nearby **SFPD incident reports** for situational awareness (for example, "37 SFPD reports within 1.2 km · 48h · mostly Larceny Theft")
- **One-blink scan.** GPT-4o vision compares the camera snapshot against every alert using clothing, hair, height, build, scars or tattoos, and vehicle make, color and plate.
- **Auto mode.** Hands-free scanning every 15 s that stays silent unless something matches.
- **Possible-match card.** It puts "You see" next to "Alert photo", lists what matched, shows a confidence bar and gives clear do / don't steps, plus a short spoken cue.
- **Report or Not a match.** Nothing is sent unless you confirm. A report logs the time, place and what matched, then shows exactly who to call.
- **Built for glasses.** Calm, minimal text, controls on the right, and a black background so the panel looks see-through on the waveguide.

## Data sources

| Source | Used for | Endpoint |
|---|---|---|
| [FBI Wanted API](https://api.fbi.gov/wanted/v1/list) (San Francisco field office) | Missing persons, crimes against children, wanted fugitives, photos, descriptions, official rewards | `api.fbi.gov/wanted/v1/list?field_offices=sanfrancisco` |
| [DataSF: SFPD Incident Reports 2018–present](https://data.sfgov.org/Public-Safety/Police-Department-Incident-Reports-2018-to-Present/wg3w-h783) | Recent incidents near you | `data.sfgov.org/resource/wg3w-h783.json` |
| Built-in **sample** Amber Alert (labeled "Sample") | A missing child and a suspect vehicle with a plate, so the vehicle flow always works. California Amber Alerts have no public API. | — |

The header always says whether you're seeing **LIVE**, **Cached** or **Offline** data.

## Safety and privacy by design

- **The human decides.** Every result is a *possible* match. The user compares the photos and chooses Report or Not a match. Nothing is reported automatically.
- **A stricter bar for real people.** Live alerts need 80%+ confidence and at least one distinctive feature, such as a tattoo, scar, specific clothing or a plate. Generic traits alone (height, hair color) are capped low, so random passersby don't get flagged.
- **Race and ethnicity are never used** in matching.
- **No vigilantism.** Guidance always says don't approach or confront, keep your distance and call the authorities. The app shows only the **official** FBI reward text, with no bounties.
- **Data stays local.** Reports are logged to `~/.amber_alert_lens/reports.json` on your device. Snapshots are only sent to OpenAI for the comparison.

Tip lines shown in the app: **911**, **1-800-CALL-FBI** / tips.fbi.gov, **SFPD 415-575-4444**, **NCMEC 1-800-THE-LOST**.

## Setup

Requires Python 3.10+.

```bash
# 1. Raven framework + starter project
git clone https://github.com/RavenResonance/raven-framework.git
cd raven-framework && pip install -e . && cd ..
git clone https://github.com/RavenResonance/raven-starter-project.git

# 2. This app
git clone <this repo>
cp amber-alert-lens/main.py amber-alert-lens/feeds.py raven-starter-project/
cp -r amber-alert-lens/assets raven-starter-project/
cd raven-starter-project
```

### Plug in your OpenAI key

Set an environment variable (recommended):

```bash
export OPENAI_API_KEY=sk-...          # macOS / Linux
$env:OPENAI_API_KEY="sk-..."          # Windows PowerShell
```

Or paste it into `OPEN_AI_KEY = ""` at the top of `main.py`, but don't commit it.

### Run

```bash
python feeds.py   # optional: check the live FBI + SFPD feeds
python main.py    # launch in the Raven simulator
```

In the simulator, your mouse is your gaze and a click is a blink. On macOS, allow camera access for Terminal or your IDE under System Settings > Privacy & Security > Camera.

### Configure

At the top of `main.py`:

| Setting | Default | Meaning |
|---|---|---|
| `HOME_LAT`, `HOME_LON`, `AREA_NAME` | Mission, SF | Where "near you" SFPD context is computed |
| `RADIUS_M` | 1200 | Radius for nearby incidents |
| `AUTO_SCAN_SECONDS` | 15 | Auto-scan interval |
| `THRESHOLD_LIVE` / `THRESHOLD_SAMPLE` | 80 / 55 | Minimum confidence to show a match |
| `SPEAK_ALERTS` | True | Spoken cue on a match |

**Quick test prop:** open `assets/alerts/car.png` on your phone and hold it up to the webcam to trigger the sample Amber Alert vehicle match.

## Project structure

```
main.py      Raven app: UI, scan flow, matching, reporting
feeds.py     FBI Wanted + DataSF fetchers, cache, report log
assets/      Alert illustrations + placeholder
docs/        Screenshots
```

## Credits

- Built on the [Raven Framework](https://github.com/RavenResonance/raven-framework) and [starter project](https://github.com/RavenResonance/raven-starter-project) by Raven Resonance
- Data: [FBI Wanted API](https://www.fbi.gov/wanted) and [DataSF](https://datasf.org/) (City and County of San Francisco)
- Vision and voice: OpenAI GPT-4o and TTS

The sample Amber Alert, its people and its vehicle are fictional. This is a hackathon prototype and not an official alerting service. In an emergency, call 911.
