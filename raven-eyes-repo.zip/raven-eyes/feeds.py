"""
Live public-safety feeds for Amber Alert Lens (San Francisco).

Sources (all public, no key needed):
  * FBI Wanted API, filtered to the San Francisco field office
      https://api.fbi.gov/wanted/v1/list?field_offices=sanfrancisco
    -> missing persons, kidnappings / crimes against children, wanted fugitives
  * DataSF - SFPD Incident Reports (2018 to present), dataset wg3w-h783
      https://data.sfgov.org/resource/wg3w-h783.json
    -> recent incidents near you, for situational context

California Amber Alerts have no public API, so the app keeps a clearly
labeled SAMPLE Amber Alert (child + vehicle) so the vehicle/plate flow can
always be shown. Everything is cached on disk so the app works offline.
"""

import html
import json
import os
import re
import time
from datetime import datetime, timedelta, timezone

try:
    import requests
except Exception:  # pragma: no cover
    requests = None

HERE = os.path.dirname(os.path.abspath(__file__))
CACHE_DIR = os.path.join(os.path.expanduser("~"), ".amber_alert_lens")
IMG_CACHE = os.path.join(CACHE_DIR, "img")
CACHE_FILE = os.path.join(CACHE_DIR, "feed_cache.json")
REPORTS_FILE = os.path.join(CACHE_DIR, "reports.json")

UA = {"User-Agent": "Mozilla/5.0 (AmberAlertLens; community-safety demo)",
      "Accept": "application/json"}

FBI_URL = "https://api.fbi.gov/wanted/v1/list"
SFPD_URL = "https://data.sfgov.org/resource/wg3w-h783.json"

# Real tip lines
TIP_FBI = "1-800-CALL-FBI · tips.fbi.gov"
TIP_SFPD = "SFPD tips 415-575-4444"
TIP_NCMEC = "1-800-THE-LOST"

AMBER = "#FFB020"
RED = "#FF5C5C"
BLUE = "#5CB8FF"
VIOLET = "#B58CFF"


def _asset(name):
    return os.path.join(HERE, "assets", "alerts", name)


# ---------------------------------------------------------------------------
# Sample Amber Alert (always available, clearly labeled)
# ---------------------------------------------------------------------------
SAMPLE_ALERTS = [
    {
        "id": "S1", "source": "SAMPLE", "source_label": "Sample Amber Alert",
        "kind": "AMBER ALERT", "type": "Missing child", "color": AMBER,
        "image": _asset("child.png"), "photo_url": None,
        "title": "Maya R., 7",
        "summary": "Red hoodie · yellow backpack",
        "features": ["red hoodie", "yellow backpack", "blue jeans", "light-up sneakers",
                     "about 4 ft", "shoulder-length dark hair with bangs", "pink glasses"],
        "distinctive": ["red hoodie + yellow backpack", "pink glasses"],
        "last_seen": "Dolores Park · 1h ago",
        "steps": ["Don't approach or follow", "Note time, place, direction",
                  "Call 911 now", "Keep her in sight from a distance"],
        "tip": "911  ·  " + TIP_NCMEC,
        "say": "Possible match. Missing child. Do not approach. Call nine one one.",
        "url": None,
    },
    {
        "id": "S2", "source": "SAMPLE", "source_label": "Sample Amber Alert",
        "kind": "AMBER ALERT", "type": "Suspect vehicle", "color": BLUE,
        "image": _asset("car.png"), "photo_url": None,
        "title": "Silver Honda Civic",
        "summary": "Plate 7KQL482 · roof rack",
        "features": ["silver Honda Civic sedan", "California plate 7KQL482",
                     "dented rear bumper", "black roof rack"],
        "distinctive": ["plate 7KQL482", "roof rack"],
        "last_seen": "US-101 N near Cesar Chavez · 40m ago",
        "steps": ["Don't follow or block the car", "Note plate, direction, time",
                  "Call 911 now", "Stay a safe distance away"],
        "tip": "911  ·  linked to Maya R. alert",
        "say": "Possible match. Amber Alert vehicle. Do not follow. Note the plate and call nine one one.",
        "url": None,
    },
]


def _clean(text, limit=None):
    if not text:
        return ""
    t = html.unescape(re.sub(r"<[^>]+>", " ", str(text)))
    t = re.sub(r"\s+", " ", t).strip()
    if limit and len(t) > limit:
        t = t[: limit - 1].rsplit(" ", 1)[0] + "…"
    return t


def _height(item):
    lo, hi = item.get("height_min"), item.get("height_max")
    try:
        lo = int(lo) if lo else None
        hi = int(hi) if hi else None
    except Exception:
        return ""
    if not lo and not hi:
        return ""
    f = lambda i: f"{i // 12}'{i % 12}\""
    if lo and hi and lo != hi:
        return f"{f(lo)}–{f(hi)}"
    return f(lo or hi)


def _fbi_to_alert(item):
    pc = (item.get("person_classification") or "").lower()
    poster = (item.get("poster_classification") or "").lower()
    subjects = " ".join(item.get("subjects") or []).lower()
    title = _clean(item.get("title"), 40).title() or "Unknown"

    if poster == "missing" or "missing" in subjects:
        kind, typ, color = "MISSING", "Missing person", AMBER
        steps = ["Don't approach. Stay calm", "Note time, place, clothing",
                 "Call 911 or FBI tips", "Keep them in sight safely"]
        say = "Possible match. Missing person. Do not approach. Call for help."
    elif "kidnap" in subjects or "children" in subjects or poster == "ecap":
        kind, typ, color = "FBI", "Crimes against children", VIOLET
        steps = ["Don't confront", "Move children to safety",
                 "Note time and direction", "Call 911 now"]
        say = "Possible match. Wanted in a crime against children. Do not confront. Call nine one one."
    else:
        kind, typ, color = "WANTED", _clean(subjects.title(), 28) or "FBI fugitive", RED
        steps = ["Don't confront. May be armed", "Move somewhere safe",
                 "Note time and direction", "Call 911 from a safe spot"]
        say = "Possible match. Wanted person. Do not confront. Move somewhere safe."
    if pc == "victim":
        kind, typ, color = "MISSING", "Victim / missing", AMBER

    feats = []
    if item.get("sex"):
        feats.append(item["sex"].lower())
    if item.get("age_range"):
        feats.append(f"age {item['age_range']}")
    elif item.get("age_min"):
        feats.append(f"age ~{item['age_min']}")
    h = _height(item)
    if h:
        feats.append(f"height {h}")
    if item.get("build"):
        feats.append(f"{item['build'].lower()} build")
    hair = item.get("hair_raw") or item.get("hair")
    if hair:
        feats.append(f"{str(hair).lower()} hair")
    distinctive = []
    marks = _clean(item.get("scars_and_marks"), 120)
    if marks:
        distinctive.append(marks)
        feats.append(marks)

    images = item.get("images") or []
    photo = None
    if images:
        photo = images[0].get("thumb") or images[0].get("large") or images[0].get("original")

    summary_bits = [b for b in [h, (str(hair).lower() + " hair") if hair else ""] if b]
    loc = _clean(", ".join(item.get("locations") or []), 40) or "SF Bay Area"
    reward_raw = _clean(item.get("reward_text"))
    m = re.search(r"\$\s?[\d,.]+(?:\s?(?:million|thousand))?", reward_raw, re.I)
    reward = f"up to {m.group(0)}" if m else _clean(reward_raw, 60)

    return {
        "id": "F" + str(item.get("uid", ""))[:8],
        "source": "FBI", "source_label": "FBI · San Francisco",
        "kind": kind, "type": typ, "color": color,
        "image": None, "photo_url": photo,
        "title": title,
        "summary": " · ".join(summary_bits) or typ,
        "features": feats,
        "distinctive": distinctive,
        "last_seen": loc,
        "details": _clean(item.get("description") or item.get("details") or item.get("caution"), 160),
        "reward": reward,
        "steps": steps,
        "tip": "911  ·  " + TIP_FBI,
        "say": say,
        "url": item.get("url"),
        "modified": item.get("modified") or "",
    }


def fetch_fbi(limit=8, timeout=12):
    """Return a list of alerts from the FBI SF field office (newest first)."""
    out = []
    params = {"field_offices": "sanfrancisco", "pageSize": 50,
              "sort_on": "modified", "sort_order": "desc"}
    r = requests.get(FBI_URL, params=params, headers=UA, timeout=timeout)
    if r.status_code >= 400:  # retry with the minimal, documented params
        r = requests.get(FBI_URL, params={"field_offices": "sanfrancisco", "pageSize": 50},
                         headers=UA, timeout=timeout)
    r.raise_for_status()
    items = r.json().get("items", [])
    # missing persons / children first, then everything else
    def rank(it):
        poster = (it.get("poster_classification") or "").lower()
        subj = " ".join(it.get("subjects") or []).lower()
        return 0 if (poster == "missing" or "missing" in subj or "kidnap" in subj
                     or "children" in subj) else 1
    items.sort(key=rank)
    for it in items:
        if (it.get("status") or "na").lower() in ("captured", "recovered", "located", "deceased"):
            continue
        try:
            out.append(_fbi_to_alert(it))
        except Exception as e:
            print(f"[feeds] skip FBI item: {e}")
        if len(out) >= limit:
            break
    return out


def fetch_sfpd_context(lat, lon, radius_m=1200, hours=48, timeout=12):
    """Recent SFPD incidents near (lat, lon). Returns dict with count + top categories."""
    since = (datetime.now() - timedelta(hours=hours)).strftime("%Y-%m-%dT%H:%M:%S")
    base = {"$select": "incident_category,incident_datetime,intersection,analysis_neighborhood",
            "$order": "incident_datetime DESC", "$limit": 500}
    rows = None
    tries = [
        f"incident_datetime > '{since}' AND within_circle(point, {lat}, {lon}, {radius_m})",
        f"incident_datetime > '{since}'",
    ]
    for where in tries:
        try:
            r = requests.get(SFPD_URL, params={**base, "$where": where}, headers=UA,
                             timeout=timeout)
            r.raise_for_status()
            rows = r.json()
            near = "within_circle" in where
            break
        except Exception as e:
            print(f"[feeds] SFPD query failed ({where[:40]}…): {e}")
    if rows is None:
        raise RuntimeError("SFPD feed unavailable")
    # SFPD data lags a few days; if the 48h window is empty, widen to 7 days
    if not rows and hours < 168:
        return fetch_sfpd_context(lat, lon, radius_m, 168, timeout)
    cats = {}
    for row in rows:
        c = (row.get("incident_category") or "Other").strip()
        cats[c] = cats.get(c, 0) + 1
    top = sorted(cats.items(), key=lambda kv: -kv[1])[:3]
    return {"count": len(rows), "hours": hours, "near": near,
            "radius_m": radius_m, "top": top,
            "latest": rows[0].get("intersection") if rows else ""}


def _download(url, uid):
    if not url:
        return None
    os.makedirs(IMG_CACHE, exist_ok=True)
    ext = ".jpg" if ".jpg" in url.lower() or ".jpeg" in url.lower() else ".png"
    path = os.path.join(IMG_CACHE, re.sub(r"\W", "", uid) + ext)
    if os.path.exists(path) and os.path.getsize(path) > 0:
        return path
    try:
        r = requests.get(url, headers={"User-Agent": UA["User-Agent"]}, timeout=10)
        r.raise_for_status()
        with open(path, "wb") as f:
            f.write(r.content)
        return path
    except Exception as e:
        print(f"[feeds] image download failed: {e}")
        return None


def load_cache():
    try:
        with open(CACHE_FILE) as f:
            data = json.load(f)
        for a in data.get("live", []):
            if a.get("image") and not os.path.exists(a["image"]):
                a["image"] = None
        return data
    except Exception:
        return None


def refresh_all(lat, lon, radius_m=1200):
    """Blocking: fetch everything. Safe to call from a background thread."""
    result = {"live": [], "context": None, "errors": [], "updated": time.time()}
    if requests is None:
        result["errors"].append("requests not installed")
        return result
    try:
        live = fetch_fbi()
        for a in live:
            a["image"] = _download(a.get("photo_url"), a["id"])
        result["live"] = live
    except Exception as e:
        result["errors"].append(f"FBI: {e}")
    try:
        result["context"] = fetch_sfpd_context(lat, lon, radius_m)
    except Exception as e:
        result["errors"].append(f"SFPD: {e}")
    if result["live"] or result["context"]:
        try:
            os.makedirs(CACHE_DIR, exist_ok=True)
            with open(CACHE_FILE, "w") as f:
                json.dump(result, f)
        except Exception as e:
            print(f"[feeds] cache write failed: {e}")
    return result


def save_report(alert, confidence, matched, lat, lon):
    os.makedirs(CACHE_DIR, exist_ok=True)
    try:
        with open(REPORTS_FILE) as f:
            reports = json.load(f)
    except Exception:
        reports = []
    rep = {"time": datetime.now(timezone.utc).isoformat(), "alert_id": alert["id"],
           "alert": alert["title"], "source": alert["source"], "confidence": confidence,
           "matched": matched, "lat": lat, "lon": lon, "url": alert.get("url")}
    reports.append(rep)
    with open(REPORTS_FILE, "w") as f:
        json.dump(reports, f, indent=2)
    return rep


if __name__ == "__main__":
    # Quick check from a terminal:  python feeds.py
    res = refresh_all(37.7596, -122.4269)
    print(f"FBI SF alerts: {len(res['live'])}")
    for a in res["live"]:
        print(f"  - [{a['kind']}] {a['title']}  ({a['type']})  photo={'yes' if a['image'] else 'no'}")
    print(f"SFPD context: {res['context']}")
    if res["errors"]:
        print("Errors:", *res["errors"], sep="\n  ")
