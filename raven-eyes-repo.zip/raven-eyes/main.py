"""
Amber Alert Lens - community safety awareness for Raven Prism (San Francisco).

* Pulls REAL public data on launch (see feeds.py):
    - FBI Wanted API, San Francisco field office: long-term missing persons,
      crimes against children, wanted fugitives (with official reward info)
    - DataSF / SFPD incident reports near you, for situational awareness
  plus a clearly labeled SAMPLE Amber Alert (child + vehicle), because
  California Amber Alerts have no public API.
* Blink Scan (or turn on Auto) and GPT-4o vision compares what you see with
  the alerts: clothing, hair, height, build, scars/tattoos, vehicle + plate.
* A possible match shows your view next to the official photo, what matched,
  a confidence level and what to do. You always make the final call:
  Report (logs it + shows the right tip line) or Not a match.
"""

import atexit
import json
import os
import re
import time
from datetime import datetime

from raven_framework import AsyncRunner, RavenApp, RunApp
from raven_framework.components.button import Button
from raven_framework.components.container import Container
from raven_framework.components.icon import Icon
from raven_framework.components.media_viewer import MediaViewer
from raven_framework.components.text_box import TextBox
from raven_framework.helpers.routine import Routine
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication

import feeds

# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------
# >>> Plug in your own OpenAI key <<<
# Either set the OPENAI_API_KEY environment variable (recommended), or paste
# your key between the quotes below. Never commit a real key to GitHub.
OPEN_AI_KEY = os.environ.get("OPENAI_API_KEY", "")  # or "sk-...your key..."

# Where you are (used for "near you" SFPD context). Default: Mission, SF.
HOME_LAT, HOME_LON = 37.7596, -122.4269
AREA_NAME = "Mission, SF"
RADIUS_M = 1200

SPEAK_ALERTS = True          # short spoken cue on a possible match
AUTO_SCAN_SECONDS = 15       # hands-free scan interval when Auto is on
REFRESH_MINUTES = 10         # re-pull live feeds
THRESHOLD_SAMPLE = 55        # min confidence for sample alerts
THRESHOLD_LIVE = 80          # real people: be much stricter
PAGE_SIZE = 3

HERE = os.path.dirname(os.path.abspath(__file__))
PLACEHOLDER = os.path.join(HERE, "assets", "alerts", "person.png")

# Palette (pure black = see-through on the waveguide)
WHITE = "#FFFFFF"
SOFT = "#D6D6D6"
DIM = "#8E8E8E"
AMBER = "#FFB020"
RED = "#FF5C5C"
GREEN = "#4ADE80"
PANEL = "#141414"
CARD = "#1E1E1E"
TRACK = "#2E2E2E"


# --------------------------------------------------------------------------
# Vision matching
# --------------------------------------------------------------------------
def build_prompt(alerts):
    lines = []
    for a in alerts:
        feats = "; ".join(a.get("features") or []) or "no description"
        dist = "; ".join(a.get("distinctive") or [])
        lines.append(f'- id {a["id"]} ({a["type"]}): {feats}'
                     + (f" | distinctive: {dist}" if dist else ""))
    return (
        "You are a cautious community-safety assistant on smart glasses in San "
        "Francisco. Compare the people and vehicles in this camera image with the "
        "active alerts below. Compare visible appearance only: clothing, carried "
        "items, hair color/style, glasses, facial hair, apparent age, height and "
        "build, scars or tattoos, and vehicle make, model, color and license plate. "
        "Never use race or ethnicity. Rules: ordinary people often share generic "
        "traits, so a match on only generic traits (sex, height, hair color) must "
        "have confidence <= 40. Confidence above 75 needs at least one distinctive "
        "feature (specific clothing combo, scar/tattoo, plate, unusual item). If "
        "nothing fits, alert_id is null.\n\n"
        "Active alerts:\n" + "\n".join(lines) + "\n\n"
        "Reply with JSON only:\n"
        '{"alert_id": "<id>" | null, "confidence": 0-100, '
        '"matched": ["2-4 short matched features"], '
        '"seen": "under 8 words describing the main person or vehicle"}'
    )


def parse_result(text, valid_ids):
    try:
        m = re.search(r"\{.*\}", text or "", re.S)
        data = json.loads(m.group(0)) if m else {}
    except Exception:
        data = {}
    aid = data.get("alert_id")
    if aid not in valid_ids:
        aid = None
    try:
        conf = int(float(data.get("confidence", 0)))
    except Exception:
        conf = 0
    matched = [str(x) for x in (data.get("matched") or [])][:4]
    seen = str(data.get("seen") or "").strip()[:60]
    return {"alert_id": aid, "confidence": conf, "matched": matched, "seen": seen}


def ask_vision(prompt, frame):
    """Call GPT vision directly so real errors (bad key, quota, network) surface."""
    import base64
    import cv2
    from openai import OpenAI
    h, w = frame.shape[:2]
    if max(h, w) > 1024:
        k = 1024 / max(h, w)
        frame = cv2.resize(frame, (int(w * k), int(h * k)))
    ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
    b64 = base64.b64encode(buf.tobytes()).decode()
    client = OpenAI(api_key=OPEN_AI_KEY.strip(), timeout=30, max_retries=1)
    last = None
    for model in ("gpt-4o", "gpt-4o-mini"):
        try:
            r = client.chat.completions.create(
                model=model, max_tokens=300,
                messages=[{"role": "user", "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url",
                     "image_url": {"url": f"data:image/jpeg;base64,{b64}"}},
                ]}],
            )
            return r.choices[0].message.content or ""
        except Exception as e:
            last = e
            print(f"[AmberAlertLens] {model} failed: {e}")
            if "model" not in str(e).lower():
                break
    raise last


def short_error(e):
    msg = str(e)
    low = msg.lower()
    if "401" in msg or "invalid_api_key" in low or "incorrect api key" in low:
        return "Invalid or expired OpenAI key (401)."
    if "insufficient_quota" in low or "429" in msg:
        return "OpenAI quota / rate limit (429). Check billing."
    if "connection" in low or "timed out" in low:
        return "Can't reach api.openai.com. Check internet."
    return msg[:110]


def confidence_label(c):
    return "High" if c >= 80 else "Medium" if c >= 60 else "Low"


def ago(ts):
    if not ts:
        return "never"
    m = int((time.time() - ts) // 60)
    return "just now" if m < 1 else f"{m}m ago" if m < 60 else f"{m // 60}h ago"


# --------------------------------------------------------------------------
# App
# --------------------------------------------------------------------------
class AmberAlertLens(RavenApp):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.view = None
        self.view_name = ""
        self.camera = None
        self.speaker = None
        self.runner = AsyncRunner()
        self.timers = []
        self.busy = False
        self.current = None
        self.page = 0
        self.auto = False
        self.auto_timer = None
        self.last_clear = None
        self.closing = False
        app = QApplication.instance()
        if app is not None:
            app.aboutToQuit.connect(self.shutdown)
        atexit.register(self._hard_exit)

        # data: cached live feed first, then refresh in background
        self.live = []
        self.context = None
        self.updated = None
        self.feed_state = "loading"   # loading | live | cached | offline
        cache = feeds.load_cache()
        if cache:
            self.live = cache.get("live") or []
            self.context = cache.get("context")
            self.updated = cache.get("updated")
            self.feed_state = "cached"
        self.show_home()
        self.refresh_feeds()
        self.refresh_timer = Routine(interval_ms=REFRESH_MINUTES * 60_000,
                                     invoke=self.refresh_feeds, mode="repeat")

    # -------------------------------------------------------------- shutdown
    def shutdown(self):
        """Stop timers, audio, camera and wait briefly for workers before Qt exits."""
        if self.closing:
            return
        self.closing = True
        self._stop_timers()
        for t in (self.auto_timer, getattr(self, "refresh_timer", None)):
            try:
                t and t.stop()
            except Exception:
                pass
        try:
            if self.speaker:
                self.speaker.stop_audio()
        except Exception:
            pass
        try:
            if self.camera:
                self.camera.close_camera()
        except Exception:
            pass
        try:
            self.runner.threadpool.waitForDone(1500)
        except Exception:
            pass

    @staticmethod
    def _hard_exit():
        # Skip interpreter teardown: Qt + OpenCV + audio threads can segfault
        # during Python finalization on macOS ("Python quit unexpectedly").
        try:
            import sys
            sys.stdout.flush()
            sys.stderr.flush()
        finally:
            os._exit(0)

    # ----------------------------------------------------------------- data
    @property
    def alerts(self):
        return self.live + feeds.SAMPLE_ALERTS

    def alert_by_id(self, aid):
        return next((a for a in self.alerts if a["id"] == aid), None)

    def refresh_feeds(self):
        holder = {}

        def work():
            try:
                holder["r"] = feeds.refresh_all(HOME_LAT, HOME_LON, RADIUS_M)
            except Exception as e:
                holder["err"] = str(e)

        def done(*_):
            if self.closing:
                return
            r = holder.get("r") or {}
            if r.get("live"):
                self.live = r["live"]
            if r.get("context"):
                self.context = r["context"]
            if r.get("live") or r.get("context"):
                self.updated = r.get("updated")
                self.feed_state = "live"
            elif self.feed_state == "loading":
                self.feed_state = "offline"
            for e in r.get("errors", []) + ([holder["err"]] if "err" in holder else []):
                print(f"[AmberAlertLens] feed: {e}")
            if self.view_name == "home":
                self.show_home()

        self.runner.run(work, on_complete=done)

    # ---------------------------------------------------------------- utils
    def _stop_timers(self):
        for t in self.timers:
            try:
                t.stop()
            except Exception:
                pass
        self.timers = []

    def _set_view(self, widget, name, y=50):
        self._stop_timers()
        if self.view is not None:
            try:
                self.view.hide()
                self.view.deleteLater()
            except Exception:
                pass
        self.view = widget
        self.view_name = name
        x = max(0, self.app.width() - widget.width() - 24)
        self.app.add(widget, x=x, y=y)
        widget.show()

    def _later(self, ms, fn):
        self.timers.append(Routine(interval_ms=ms, invoke=fn, mode="delay"))

    def _every(self, ms, fn):
        self.timers.append(Routine(interval_ms=ms, invoke=fn, mode="repeat"))

    @staticmethod
    def _t(text, size=20, color=WHITE, bold=False, width=300, align="left"):
        return TextBox(text=text, font_size=size, text_color=color,
                       font_weight="bold" if bold else "normal",
                       width=width, alignment=align)

    @staticmethod
    def _btn(text, cb, *args, width=160, height=64, size=22):
        b = Button(center_text=text, width=width, height=height, text_size=size)
        b.on_clicked(cb, *args)
        return b

    @staticmethod
    def _photo(alert):
        p = alert.get("image")
        return p if p and os.path.exists(p) else PLACEHOLDER

    @staticmethod
    def _img(path, size):
        size -= size % 4
        try:
            return MediaViewer(media_path=path or PLACEHOLDER, width=size, height=size,
                               corner_radius=18, scale_mode="cover")
        except Exception:
            return Container(width=size, height=size, background_color=TRACK,
                             corner_radius=18)

    def _thumb(self, alert, size, cb):
        try:
            ic = Icon(background_image_path=self._photo(alert), size=size,
                      is_square=True, corner_radius=18, outline_color=alert["color"],
                      dwell_time=900)
            ic.on_clicked(cb, alert["id"])
            return ic
        except Exception:
            return self._img(self._photo(alert), size)

    @staticmethod
    def _bar(width, pct, color):
        track = Container(width=width, height=10, background_color=TRACK, corner_radius=5)
        fill = Container(width=max(10, int(width * max(0, min(100, pct)) / 100)),
                         height=10, background_color=color, corner_radius=5)
        track.add(fill, x=0, y=0)
        track.fill = fill
        return track

    def _status_line(self):
        if self.feed_state == "live":
            return f"●  LIVE · FBI SF + SFPD · {ago(self.updated)}", GREEN
        if self.feed_state == "cached":
            return f"●  Cached · updated {ago(self.updated)} · refreshing", AMBER
        if self.feed_state == "loading":
            return "●  Connecting to FBI + SFPD feeds…", DIM
        return "●  Offline · showing sample alert only", AMBER

    def _context_line(self):
        c = self.context
        if not c:
            return f"{AREA_NAME}"
        where = f"within {c['radius_m'] / 1000:.1f} km" if c.get("near") else "citywide"
        top = c["top"][0][0] if c.get("top") else ""
        span = f"{c['hours']}h" if c["hours"] < 168 else "7 days"
        return f"{c['count']} SFPD reports {where} · {span}" + (f" · mostly {top}" if top else "")

    # ----------------------------------------------------------------- home
    def show_home(self):
        alerts = self.alerts
        pages = max(1, (len(alerts) + PAGE_SIZE - 1) // PAGE_SIZE)
        self.page %= pages
        shown = alerts[self.page * PAGE_SIZE:(self.page + 1) * PAGE_SIZE]

        p = Container(width=600, height=540, background_color=PANEL, corner_radius=30)
        p.add(self._t("Amber Alert Lens", size=30, bold=True, width=380), x=28, y=22)
        status, scol = self._status_line()
        p.add(self._t(status, size=15, color=scol, width=380), x=30, y=62)
        p.add(self._t(self._context_line(), size=14, color=DIM, width=380), x=30, y=84)

        y = 120
        for a in shown:
            p.add(self._thumb(a, 84, self.show_detail), x=28, y=y)
            p.add(self._t(f"{a['kind']} · {a['type']}", size=14, color=a["color"],
                          bold=True, width=270), x=128, y=y + 2)
            p.add(self._t(a["title"], size=20, bold=True, width=270), x=128, y=y + 22)
            p.add(self._t(a["summary"], size=15, color=SOFT, width=270), x=128, y=y + 50)
            p.add(self._t(a["source_label"], size=13, color=DIM, width=270), x=128, y=y + 70)
            y += 108

        foot = f"{self.page + 1} / {pages}   ·   Look at a photo to open it"
        if self.auto:
            foot = ("Auto-scan on" + (f" · clear at {self.last_clear}" if self.last_clear else "")
                    + f"   ·   {self.page + 1} / {pages}")
        p.add(self._t(foot, size=14, color=DIM, width=380), x=30, y=y + 8)

        # right-side controls
        p.add(self._btn("◎  Scan", self.start_scan, width=160, height=96, size=26), x=416, y=120)
        p.add(self._btn("Auto: On" if self.auto else "Auto: Off", self.toggle_auto,
                        width=160, height=60, size=20), x=416, y=232)
        if pages > 1:
            p.add(self._btn("More  ›", self.next_page, width=160, height=60, size=20),
                  x=416, y=308)
        p.add(self._t("Never approach.\nYou make the call.", size=13, color=DIM, width=170),
              x=420, y=390)
        self._set_view(p, "home")

    def next_page(self):
        self.page += 1
        self.show_home()

    # --------------------------------------------------------------- detail
    def show_detail(self, aid):
        a = self.alert_by_id(aid)
        if not a:
            return
        c = a["color"]
        p = Container(width=600, height=540, background_color=PANEL, corner_radius=30,
                      border_width=2, border_color=c)
        p.add(self._img(self._photo(a), 152), x=28, y=28)
        p.add(self._t(f"{a['kind']} · {a['type']}", size=14, color=c, bold=True, width=210),
              x=196, y=30)
        p.add(self._t(a["title"], size=24, bold=True, width=210), x=196, y=52)
        p.add(self._t(a["source_label"], size=13, color=DIM, width=210), x=196, y=118)
        if a.get("reward"):
            p.add(self._t("Official reward " + a["reward"], size=13, color=AMBER, width=210),
                  x=196, y=138)

        y = 196
        feats = ", ".join(a.get("features") or [])
        if feats:
            p.add(self._t("DESCRIPTION", size=13, color=c, bold=True, width=370), x=28, y=y)
            p.add(self._t(feats, size=16, width=370), x=28, y=y + 20)
            y += 20 + 22 * min(3, 1 + len(feats) // 40) + 6
        p.add(self._t("Last known  " + a["last_seen"], size=14, color=DIM, width=370), x=28, y=y)
        y += 30
        p.add(self._t("IF YOU SEE THEM", size=13, color=c, bold=True, width=370), x=28, y=y)
        y += 22
        for i, s in enumerate(a["steps"], 1):
            p.add(self._t(f"{i}   {s}", size=16, width=370), x=28, y=y)
            y += 25
        p.add(self._t(a["tip"], size=14, color=SOFT, bold=True, width=370), x=28, y=y + 6)

        p.add(self._btn("◎  Scan", self.start_scan, width=160, height=80, size=24), x=416, y=196)
        p.add(self._btn("‹  Back", self.show_home, width=160, height=60, size=20), x=416, y=290)
        self._set_view(p, "detail")

    # ------------------------------------------------------------- scanning
    def _scanning_view(self, subtitle):
        p = Container(width=420, height=190, background_color=PANEL, corner_radius=30)
        title = self._t("Scanning", size=30, bold=True, width=300)
        p.add(title, x=28, y=26)
        p.add(self._t(subtitle, size=16, color=DIM, width=360), x=28, y=72)
        p.add(self._t("Clothing · appearance · marks · vehicles · plates", size=14,
                      color=SOFT, width=364), x=28, y=104)
        bar = self._bar(364, 3, AMBER)
        p.add(bar, x=28, y=150)
        self._set_view(p, "scanning")
        state = {"pct": 3, "dots": 0}

        def tick():
            state["pct"] = min(96, state["pct"] + 3)
            state["dots"] = (state["dots"] + 1) % 4
            try:
                bar.fill.setFixedSize(max(10, int(364 * state["pct"] / 100)), 10)
                title.set_text("Scanning" + "." * state["dots"])
            except Exception:
                pass

        self._every(90, tick)

    # ------------------------------------------------------------------ scan
    def toggle_auto(self):
        self.auto = not self.auto
        if self.auto_timer:
            self.auto_timer.stop()
            self.auto_timer = None
        if self.auto:
            self.auto_timer = Routine(interval_ms=AUTO_SCAN_SECONDS * 1000,
                                      invoke=self._auto_tick, mode="repeat")
        self.show_home()

    def _auto_tick(self):
        if self.closing:
            return
        if self.auto and not self.busy and self.view_name == "home":
            self.start_scan(quiet=True)

    def start_scan(self, quiet=False):
        if self.busy or self.closing:
            return
        if not OPEN_AI_KEY:
            self.show_message("Add your OpenAI key",
                              "Set OPENAI_API_KEY or paste it into\nOPEN_AI_KEY at the top of main.py.",
                              RED, hold_ms=5000)
            return
        self.busy = True
        if not quiet:
            self._scanning_view(f"Comparing with {min(12, len(self.alerts))} alerts near {AREA_NAME}")
        # Let the scanning screen paint, then grab the frame on the MAIN thread.
        # (macOS AVFoundation crashes if the camera is touched from a worker thread.)
        QTimer.singleShot(60, lambda: self._capture_and_match(quiet))

    def _grab_frame(self):
        if self.camera is None:
            from raven_framework.peripherals.camera import Camera
            self.camera = Camera()
        frame = None
        try:
            self.camera.open_camera()
            for _ in range(5):  # let auto-exposure settle
                f = self.camera.capture_camera_image()
                if f is not None:
                    frame = f
        finally:
            try:
                self.camera.close_camera()
            except Exception:
                pass
        return None if frame is None else frame.copy()

    def _capture_and_match(self, quiet):
        if self.closing:
            return
        try:
            frame = self._grab_frame()
        except Exception as e:
            frame = None
            print(f"[AmberAlertLens] camera error: {e}")
        if frame is None:
            self.busy = False
            if not quiet:
                self.show_message("Camera unavailable",
                                  "Allow camera access for Terminal/Python in\nSystem Settings > Privacy > Camera.",
                                  RED, hold_ms=6000)
            return

        alerts = self.alerts[:12]
        valid = {a["id"] for a in alerts}
        prompt = build_prompt(alerts)
        snapshot = self._save_snapshot(frame)
        holder = {}

        def work():  # background: network only, no Qt / camera
            try:
                reply = ask_vision(prompt, frame)
                print(f"[AmberAlertLens] model reply: {reply}")
                if not (reply or "").strip():
                    holder["error"] = "Empty reply from OpenAI."
                    return
                holder["result"] = parse_result(reply, valid)
            except Exception as e:
                holder["error"] = short_error(e)

        def done(*_):
            self.busy = False
            if self.closing:
                return
            if "error" in holder:
                if quiet:
                    print(f"[AmberAlertLens] auto-scan error: {holder['error']}")
                    return
                self.show_message("Scan failed", holder["error"], RED, hold_ms=7000)
                return
            res = holder.get("result") or {}
            res["snapshot"] = snapshot
            self.show_result(res, quiet=quiet)

        self.runner.run(work, on_complete=done)

    @staticmethod
    def _save_snapshot(frame):
        try:
            import tempfile
            import cv2
            h, w = frame.shape[:2]
            s = min(h, w)
            crop = frame[(h - s) // 2:(h + s) // 2, (w - s) // 2:(w + s) // 2]
            path = os.path.join(tempfile.gettempdir(),
                                f"amber_lens_{int(time.time() * 1000)}.png")
            cv2.imwrite(path, cv2.resize(crop, (240, 240)))
            return path
        except Exception as e:
            print(f"[AmberAlertLens] snapshot save failed: {e}")
            return None

    # ---------------------------------------------------------------- result
    def show_result(self, result, quiet=False):
        result = result or {}
        a = self.alert_by_id(result.get("alert_id")) if result.get("alert_id") else None
        conf = int(result.get("confidence", 0))
        need = THRESHOLD_SAMPLE if (a and a["source"] == "SAMPLE") else THRESHOLD_LIVE
        if not a or conf < need:
            self.last_clear = datetime.now().strftime("%I:%M %p").lstrip("0")
            if quiet:
                if self.view_name == "home":
                    self.show_home()
                return
            self.show_no_match(result)
            return

        matched = result.get("matched") or (a.get("features") or [])[:2]
        self.current = (a, result)
        c = a["color"]
        p = Container(width=600, height=540, background_color=PANEL, corner_radius=30,
                      border_width=2, border_color=c)
        p.add(self._t("POSSIBLE MATCH", size=15, color=c, bold=True, width=260), x=28, y=20)

        # side-by-side: what you see vs official photo
        p.add(self._img(result.get("snapshot") or PLACEHOLDER, 120), x=28, y=48)
        p.add(self._img(self._photo(a), 120), x=160, y=48)
        p.add(self._t("You see", size=12, color=DIM, width=120), x=28, y=172)
        p.add(self._t("Alert photo", size=12, color=DIM, width=120), x=160, y=172)

        p.add(self._t(f"{a['kind']} · {a['type']}", size=14, color=c, bold=True, width=370),
              x=28, y=200)
        p.add(self._t(a["title"], size=24, bold=True, width=370), x=28, y=220)
        p.add(self._t(f"{confidence_label(conf)} confidence · {conf}%", size=15, color=c,
                      bold=True, width=200), x=28, y=256)
        p.add(self._bar(160, conf, c), x=236, y=262)
        p.add(self._t("Matched:  " + "  ·  ".join(matched), size=16, width=370), x=28, y=284)

        p.add(self._t("WHAT TO DO", size=13, color=c, bold=True, width=370), x=28, y=338)
        y = 360
        for i, step in enumerate(a["steps"], 1):
            p.add(self._t(f"{i}   {step}", size=16, width=370), x=28, y=y)
            y += 25
        p.add(self._t(a["tip"], size=14, color=SOFT, bold=True, width=370), x=28, y=y + 6)

        p.add(self._btn("Report", self.report, width=160, height=72, size=24), x=416, y=48)
        p.add(self._btn("Not a match", self.dismiss, width=160, height=60, size=20),
              x=416, y=134)
        p.add(self._t("Compare the photos.\nYou make the call.\nNothing is sent\nunless you Report.",
                      size=13, color=DIM, width=170), x=420, y=206)
        self._set_view(p, "match")
        self.speak(a["say"])

    def show_no_match(self, result):
        p = Container(width=440, height=200, background_color=PANEL, corner_radius=30,
                      border_width=2, border_color=GREEN)
        x = 28
        if result.get("snapshot"):
            p.add(self._img(result["snapshot"], 144), x=28, y=28)
            x = 192
        p.add(self._t("No match", size=28, color=GREEN, bold=True, width=230), x=x, y=30)
        seen = result.get("seen")
        p.add(self._t(f"Saw: {seen}" if seen else "Nothing matches local alerts.",
                      size=16, color=SOFT, width=230), x=x, y=76)
        p.add(self._t("Stay aware.", size=14, color=DIM, width=230), x=x, y=144)
        self._set_view(p, "nomatch")
        self._later(3500, self.show_home)

    # ---------------------------------------------------------------- report
    def report(self):
        if not self.current:
            return
        a, result = self.current
        try:
            feeds.save_report(a, result.get("confidence"), result.get("matched"),
                              HOME_LAT, HOME_LON)
        except Exception as e:
            print(f"[AmberAlertLens] report log failed: {e}")
        stamp = datetime.now().strftime("%I:%M %p").lstrip("0")
        p = Container(width=480, height=330, background_color=PANEL, corner_radius=30,
                      border_width=2, border_color=GREEN)
        p.add(self._t("Sighting logged", size=28, color=GREEN, bold=True, width=420), x=28, y=24)
        p.add(self._t(f"{a['title']} · {stamp} · near {AREA_NAME}", size=15, color=SOFT,
                      width=420), x=28, y=66)
        p.add(self._t("CALL NOW", size=13, color=AMBER, bold=True, width=420), x=28, y=104)
        p.add(self._t("Immediate danger:  911", size=22, bold=True, width=420), x=28, y=126)
        tip = a["tip"].split("·", 1)[-1].strip() if "·" in a["tip"] else a["tip"]
        p.add(self._t(f"Tip line:  {tip}", size=18, width=420), x=28, y=162)
        p.add(self._t("Share the time, place and what matched.\nStay at a safe distance.",
                      size=15, color=DIM, width=300), x=28, y=206)
        p.add(self._btn("Done", self.show_home, width=120, height=60, size=20), x=332, y=246)
        self._set_view(p, "report")

    def dismiss(self):
        self.show_message("Marked not a match", "Thanks. Nothing was sent.", DIM, hold_ms=1600)

    def show_message(self, title, body, color, hold_ms=2600):
        p = Container(width=440, height=180, background_color=PANEL, corner_radius=30,
                      border_width=2, border_color=color)
        p.add(self._t(title, size=26, color=color, bold=True, width=390), x=28, y=26)
        p.add(self._t(body, size=17, color=SOFT, width=390), x=28, y=70)
        self._set_view(p, "message")
        self._later(hold_ms, self.show_home)

    # ----------------------------------------------------------------- audio
    def speak(self, text):
        if not (SPEAK_ALERTS and OPEN_AI_KEY):
            return
        try:
            if self.speaker is None:
                from raven_framework.peripherals.speaker import Speaker
                self.speaker = Speaker()
        except Exception as e:
            print(f"[AmberAlertLens] audio init failed: {e}")
            return
        holder = {}

        def work():
            try:
                from openai import OpenAI
                client = OpenAI(api_key=OPEN_AI_KEY.strip(), timeout=20, max_retries=0)
                r = client.audio.speech.create(model="tts-1", voice="nova", input=text,
                                               response_format="wav")
                holder["wav"] = r.content
            except Exception as e:
                print(f"[AmberAlertLens] TTS failed: {e}")

        def done(*_):
            if holder.get("wav") and not self.closing:
                try:
                    self.speaker.stop_audio()
                    self.speaker.play_audio(holder["wav"])
                except Exception as e:
                    print(f"[AmberAlertLens] playback failed: {e}")

        self.runner.run(work, on_complete=done)


if __name__ == "__main__":
    RunApp.run(lambda: AmberAlertLens(), app_id="", app_key="")
